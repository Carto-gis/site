Edge bundling for Processing
----------------------------
This plugin implements force-based edge bundling for the QGIS Processing framework.
Requires QGIS >= 3.0

For a usage demo check: https://anitagraser.com/2018/01/28/porting-processing-scripts-to-qgis3/
